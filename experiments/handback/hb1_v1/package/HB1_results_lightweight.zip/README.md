# HB1 lightweight results

This archive contains code, configuration, compact metrics, figures, and the report. Model weights, raw trajectories, replay buffers, Parquet tables, and videos are intentionally excluded.
