# HB1-R lightweight results

This archive contains compact configuration, capability and formal-probe summaries, the report, and recovery_handback Python source. Model weights, training state, raw datasets, trajectories, Parquet tables, videos, and full logs are excluded.
